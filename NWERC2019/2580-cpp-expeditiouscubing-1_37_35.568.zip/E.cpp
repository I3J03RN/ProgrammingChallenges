#include <cstdio>
#include <algorithm>
#include <numeric>
#include <cmath>
using namespace std;



int main() {
  double t[4], target;
  scanf("%lf %lf %lf %lf %lf", t , t + 1, t + 2, t + 3, &target);
  sort(t, t + 4);
  if ((t[0] + t[1] +t[2]) / 3.0 > target) {
    printf("impossible\n");
  } else if ((t[1] + t[2] + t[3]) / 3.0 <= target) {
    printf("infinite\n");
  } else {
    printf("%.2lf\n",round( (3 * target - (t[1] + t[2])) * 100.0) / 100.0);
  }
}
